#include <gtest/gtest.h>
#include <odd-even-sort.hpp>
#include <odd-even-sequential.hpp>
#include <random>
#include <mpi.h>

using namespace sort;
std::unique_ptr<Context> context;



TEST(OddEvenSort, Random) {
    int rank;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    if (rank == 0) {
        std::vector<Element> data(100000);
        auto dev = std::random_device{};
        auto seed = 500;
        auto gen = std::default_random_engine(seed);
        auto dist = std::uniform_int_distribution<Element>{};
        for (auto &i : data) {
            i = dist(gen);
        }
        //data={11,2,3,4,5,6,7,8,9,10};
        std::vector<Element> a = data;
        std::vector<Element> b = data;
        auto info=context->mpi_sort(a.data(), a.data() + a.size());
        std::sort(b.data(), b.data() + b.size());
        EXPECT_EQ(a, b) << " seeded with: " << seed << std::endl;
        context->print_information(*info,std::cout);
    } else {
        context->mpi_sort(nullptr, nullptr);
    }
}


//std::unique_ptr<sequential_sort::ContextSeq> contextseq;

TEST(OddEvenSortSequential, Random) {
    int rank;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    if (rank == 0) {
    std::vector<Element> data(100000);
    auto dev = std::random_device{};
    auto seed = 500;
    auto gen = std::default_random_engine(seed);
    auto dist = std::uniform_int_distribution<Element>{};
    for (auto &i : data) {
        i = dist(gen);
    }
    //data={11,2,3,4,5,6,7,8,9,10};
    std::vector<Element> a = data;
    std::vector<Element> b = data;
    auto info=seq_sort(a.data(),a.data()+a.size());
    std::sort(b.data(), b.data() + b.size());
    print_information(*info,std::cout);
    EXPECT_EQ(a, b) << " seeded with: " << seed << std::endl;

    }
}

int main(int argc, char **argv) {

    context = std::make_unique<Context>(argc, argv);
    int rank;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    ::testing::InitGoogleTest(&argc, argv);
    ::testing::TestEventListeners &listeners =
            ::testing::UnitTest::GetInstance()->listeners();
    if (rank != 0) {
        delete listeners.Release(listeners.default_result_printer());
    }

    auto res = RUN_ALL_TESTS();
    context.reset();
    return res;
}
