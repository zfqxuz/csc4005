#include <odd-even-sort.hpp>
#include <odd-even-sequential.hpp>
#include <mpi.h>
#include <iostream>
#include <fstream>
#include <vector>
#include <random>

void do_seq(int argc, char **argv){


    Element element;
    std::vector<Element> data(strtol(argv[1],NULL,10));

    auto dev = std::random_device{};
    auto seed = 500;
    auto gen = std::default_random_engine(seed);
    auto dist = std::uniform_int_distribution<Element>{};
    for (auto &i : data) {
        i = dist(gen);
    }
    auto info_seq = seq_sort(data.data(),data.data()+data.size());
    print_information(*info_seq,std::cout);
}

void do_mpi(int argc,char** argv){
    sort::Context context(argc, argv);
    int rank;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    if (argc < 2) {
        if(rank==0){
            std::cerr << "wrong arguments" << std::endl;
            std::cerr << "usage: " << argv[0] << " <sample size>" << std::endl;
        }
        return;
    }
    sort::Element element;
    std::vector<sort::Element> data(strtol(argv[1],NULL,10));
    if (rank == 0) {

        auto dev = std::random_device{};
        auto seed = 500;
        auto gen = std::default_random_engine(seed);
        auto dist = std::uniform_int_distribution<sort::Element>{};
        for (auto &i : data) {
            i = dist(gen);
        }
        auto info_mpi = context.mpi_sort(data.data(), data.data() + data.size());
        sort::Context::print_information(*info_mpi, std::cout);
    } else {
        context.mpi_sort(nullptr, nullptr);
    }
    if(rank==0){ do_seq(argc,argv);}

}





int main(int argc, char **argv) {
    do_mpi(argc,argv);


}


