#include <odd-even-sort.hpp>
#include <mpi.h>
#include <iostream>
#include <vector>
#include <chrono>

namespace sort {
    using namespace std::chrono;


    Context::Context(int &argc, char **&argv) : argc(argc), argv(argv) {
        MPI_Init(&argc, &argv);
    }

    Context::~Context() {
        MPI_Finalize();
    }

    void print_mem(Element* begin,int count){
        Element * start=begin;
        for (int i = 0; i < count; ++i){
            std::cout<<*(start+i)<<" | ";
        }
    }

    void print_mem(Element* begin,Element * end){
        Element * start=begin;
        Element * fin=end;
        while (start<fin){
            std::cout<<*(start)<<" & ";
            start++;
        }
    }


    void print_vector(std::vector<Element> j, int rank, int flag) {
        if (true) {
            if (flag == 0) {
                std::cout << "before: ";
            } else {
                std::cout << "after : ";
            }
            std::cout << rank << "--->";
            for (int i = 0; i < j.size(); ++i) {
                std::cout << j[i] << " ";

            }
            std::cout << std::endl;
        }

    }

    int compare_and_swap(Element *start, int count) {


        int groups = count / 2;
        int total=0;
        for (int i = 0; i < groups; i++) {
            Element *first = start + 2 * i;
            Element *second = start + 2 * i + 1;
            if (*first > *second) {
                total++;
                Element temp = *first;
                *first = *second;
                *second = temp;
            }
        }
        return total;
    }

    std::unique_ptr<Information> Context::mpi_sort(Element *begin, Element *end) const {
        int res;
        int rank;
        std::unique_ptr<Information> information{};

        res = MPI_Comm_rank(MPI_COMM_WORLD, &rank);
        if (MPI_SUCCESS != res) {
            throw std::runtime_error("failed to get MPI world rank");
        }
        if (0 == rank) {
            printf("MPI start");
            information = std::make_unique<Information>();
            information->length = end - begin;
            res = MPI_Comm_size(MPI_COMM_WORLD, &information->num_of_proc);
            if (MPI_SUCCESS != res) {
                throw std::runtime_error("failed to get MPI world size");
            };
            information->argc = argc;
            for (auto i = 0; i < argc; ++i) {
                information->argv.push_back(argv[i]);
            }
            information->start = high_resolution_clock::now();
        }

        {
            /// now starts the main sorting procedure
            /// @todo: please modify the following code
            int size, np, makes, modified_size, step = 0;
            Element * orig= nullptr;
            if (0 == rank) {

                size = information->length;
                modified_size = size;
                np = std::max(information->num_of_proc - 1, 1);
                makes = np - (modified_size % np);
                modified_size += makes;
                step = modified_size / np;
//                std::cout << "np=?" << np << std::endl;
//                std::cout << "makes=?" << makes << std::endl;
//                std::cout << "step=?" << step << std::endl;
//                std::cout << "modified=?" << modified_size << std::endl;
                /// modify to even group members;
                if (step % 2 == 1) {
                    makes += np;
                    step += 1;
                    modified_size += np;
                }
//                std::cout << "np=!" << np << std::endl;
//                std::cout << "makes=!" << makes << std::endl;
//                std::cout << "step=!" << step << std::endl;
//                std::cout << "modified=!" << modified_size << std::endl;
                if(np>1){
                    orig=(Element*)calloc(sizeof (Element),(modified_size+step));
                    std::fill(orig,orig+modified_size+step,INT64_MAX);
                    memcpy(orig+step,begin,size*sizeof (Element));
                    //print_mem(orig,modified_size+step);
                }

            }
            MPI_Bcast(&np, 1, MPI_INT, 0, MPI_COMM_WORLD);
            MPI_Bcast(&step, 1, MPI_INT, 0, MPI_COMM_WORLD);
            ///ODD-EVEN SORTING BODY
            int count = 0, clk = 0;
            if(np==1){
                if(rank==0){
                    while (!std::is_sorted(begin,end)){
                        Element * start=begin+clk;
                        compare_and_swap(start,end-begin-clk);
                        clk=!clk;
                    }
                }
            }else{
                //std::cout<<"rank"<<rank;

                std::vector<Element> temp(step + 2, INT64_MAX);
                ///temp is a buffer whose size is step+2, as it will have slots at the head and tail for exchanged data.
                ///The owned data takes [1,step]slots. Data from previous process will use [0] and data from next process will use [step+1]
                ///initially, [0]is filled with min and[step+1] is filled with max int.
                MPI_Scatter(orig, step, MPI_INT64_T, &temp[1], step, MPI_INT64_T, 0, MPI_COMM_WORLD);
                //print_vector(temp,-rank,0);

            ///at posedge clk, even process send its first half data to previous one and wait for the sendback
            ///meanwhile, odd process receive data from previous(except the last one if total #proc is odd) and store in the second half
            ///during clk=1, odd process deal with the total data received{
            /// 1.if the data already sorted, set the result to 0;
            /// 2.if not sort the data, set the result to 1;
            /// }
            ///root exam the sum of result. if sum=0, then all subarrays are sorted. then stop loop and go on.Else, change clk, continue.
            ///at negedge clk, the sender become receiver, the receiver become sender.
            int result = 10;
            std::vector<int> results(np + 1, 1);
            int total=0;
            Element *judge_start=&temp[0];
                if (rank == 1){
                    //printf("jiejie %lx",temp[step+1]);
                    judge_start=&temp[1];
                }
            Element *judge_end=&temp[step+2];
                if (rank == np){
                    judge_end=&temp[step+1];
                }
            while (true) {
                MPI_Gather(&result, 1, MPI_INT, &results[rank], 1, MPI_INT, 0, MPI_COMM_WORLD);
                if (rank != 0) {
                    if (clk == 0) {
                        ///     at clk=0, all conduct internal sorting. After that, send heads to the tail of previous
                        /// and send its tail to the next head.
                        //print_vector(temp, rank * 1000 + count * 10 + clk, 0);
                        total+=compare_and_swap(&temp[1], step);
                        //print_vector(temp, rank * 1000 + count * 10 + clk, 1);
                        //if(rank==2){std::cout << rank << " count " << count <<" total "<< total << std::endl;}
                        if ((rank > 1)) {
                            MPI_Send(&temp[1], 1, MPI_INT64_T, rank - 1, 123, MPI_COMM_WORLD);
                        }
                        if ((rank < np)) {
                            MPI_Send(&temp[step], 1, MPI_INT64_T, rank + 1, 321, MPI_COMM_WORLD);
                        }
                    } else {
                        //print_vector(temp, rank * 1000 + count * 10 + clk, 0);
                        ///     at clk=1, all receive from its previous and next. If it is first/last process, ignore the
                        /// first/last number and do sorting. No need to do any transform after sorting.

                        if (rank != 1) {
                            MPI_Recv(&temp[0], 1, MPI_INT64_T, rank - 1, 321, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
                        }
                        if (rank != np) {
                            MPI_Recv(&temp[step + 1], 1, MPI_INT64_T, rank + 1, 123, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
                        }

                            if (rank == 1) {
                                ///head will ignore the first num and an unused data slot
                                total+=compare_and_swap(&temp[2], step);
                            } else if (rank == np) {
                                ///tail will ignore the last num and an unused data slot
                                total+=compare_and_swap(&temp[0], step);
                            } else {
                                total+=compare_and_swap(&temp[0], step + 2);
                            }


                        //print_vector(temp, rank * 1000 + count * 10 + clk, 1);
                    }
                    //print_mem(judge_start,judge_end);
                    if (std::is_sorted(judge_start,judge_end)) {
                        result = 0;
                    } else{result=1;}
                    //print_vector(temp,1000*rank+100*count+result,1);
                    clk = !clk;
                } else {
                    ///rank 0 as monitor will gather the results generated in other processes
                    for (int i = 1; i < np + 1; i++) {
                        results[0] += results[i];
                    }
                    if (results[0] == 10) {
                        results[0] = -1;
                    } else { results[0] = 1; }
                }
                MPI_Bcast(&results[0], 1, MPI_INT, 0, MPI_COMM_WORLD);

                ///This Barrier ensures the Bcast in rank 0 sends result to every processes


                if (results[0] == -1) {
                    break;
                } else if (clk == 0) {
                    ///to avoid block, we will not send data until it really needs. If the sorting completed at clk=0,
                    ///it will not send any data. There's no data passing at clk=1 regardless of completeness. Thus there will
                    ///not be blocks.

                }
                count++;

            }
            ///collect
            //std::cout<<rank<<"compares"<<total<<std::endl;
            std::vector<Element> j(step * (np + 1), -1);
            MPI_Gather(&temp[1], step, MPI_INT64_T, &j[0], step, MPI_INT64_T, 0, MPI_COMM_WORLD);
            if (rank == 0) {
//                print_vector(j, -9, 1);
//                std::cout << "NUM PROC=?" << np << std::endl;
//                std::cout << "SIZE" << size << std::endl;
//                std::cout << "J_SIZE" << j.size() << std::endl;
//                std::cout << "STEP=?" << step << std::endl;
                memcpy(begin, &j[step], sizeof(int64_t) * size);
                free(orig);
            }
        }
        }

        if (0 == rank) {
            information->end = high_resolution_clock::now();
        }

        return information;

    }

    std::ostream &Context::print_information(const Information &info, std::ostream &output) {
        output<<"\nMPI Sort Result:"<<std::endl;
        auto duration = info.end - info.start;

        auto duration_count = duration_cast<nanoseconds>(duration).count();
        auto mem_size = static_cast<double>(info.length) * sizeof(Element) / 1024.0 / 1024.0 / 1024.0;
        output << "     input size: " << info.length << std::endl;
        output << "     proc number: " << info.num_of_proc << std::endl;
        output << "     duration (ns): " << duration_count << std::endl;
        output << "     throughput (gb/s): " << mem_size / static_cast<double>(duration_count) * 1'000'000'000.0
               << std::endl;
        return output;
    }


}
