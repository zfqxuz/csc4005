#include <odd-even-sequential.hpp>
#include <iostream>
#include <vector>
#include <chrono>



int compare_and_swap(Element *start, int count) {
    int groups = count / 2;
    int total=0;
        for (int i = 0; i < groups; i++) {

            Element *first = start + 2 * i;
            Element *second = start + 2 * i + 1;
            if (*first > *second) {
                total++;
                Element temp = *first;
                *first = *second;
                *second = temp;
            }
        }
    return total;
}

void print_vector(std::vector<Element> j, int rank, int flag) {
    if (true) {
        if (flag == 0) {
            std::cout << "before: ";
        } else {
            std::cout << "after : ";
        }
        std::cout << rank << "--->";
        for (int i = 0; i < j.size(); ++i) {
            std::cout << j[i] << " ";

        }
        std::cout << std::endl;
    }

}

std::unique_ptr<Information> seq_sort(Element *begin, Element *end) {
    printf("Sequential start");
    std::unique_ptr<Information> information{};
    information = std::make_unique<Information>();
    information->length = end - begin;
    information->start = std::chrono::high_resolution_clock::now();
    int clk=0;
    int total=0;
    while (!std::is_sorted(begin,end)){
        Element * start=begin+clk;
        total+=compare_and_swap(start,end-begin-clk);
        clk=!clk;
    }

    information->end = std::chrono::high_resolution_clock::now();

    return information;
}

std::ostream &print_information(const Information &info, std::ostream &output) {
    output<<"\nSequential Sort Result:"<<std::endl;
    auto duration = info.end - info.start;

    auto duration_count = duration_cast<std::chrono::nanoseconds>(duration).count();
    auto mem_size = static_cast<double>(info.length) * sizeof(Element) / 1024.0 / 1024.0 / 1024.0;
    output << "     input size: " << info.length << std::endl;
    output << "     proc number: " << 1 << std::endl;
    output << "     duration (ns): " << duration_count << std::endl;
    output << "     throughput (gb/s): " << mem_size / static_cast<double>(duration_count) * 1'000'000'000.0
           <<std::endl;
    return output;
}



