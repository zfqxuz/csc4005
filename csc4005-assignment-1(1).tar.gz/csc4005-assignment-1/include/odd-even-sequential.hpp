#ifndef CSC4005_ASSIGNMENT_1_ODD_EVEN_SEQUENTIAL_HPP
#define CSC4005_ASSIGNMENT_1_ODD_EVEN_SEQUENTIAL_HPP
#include <cstdint>
#include <cstddef>
#include <memory>
#include <chrono>
#include <vector>
using Element = int64_t;
struct Information {
    std::chrono::high_resolution_clock::time_point start{};
    std::chrono::high_resolution_clock::time_point end{};
    size_t length{};
    int num_of_proc{};
    int argc{};
    std::vector<char *> argv{};
};
std::unique_ptr<Information> seq_sort(Element *begin, Element *end);
std::ostream &print_information(const Information &info, std::ostream &output);


#endif //CSC4005_ASSIGNMENT_1_ODD_EVEN_SEQUENTIAL_HPP
